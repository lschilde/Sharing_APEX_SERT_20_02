--  Copyright (c) sumneva 2010. All Rights Reserved.
--
--    NAME
--      user_grants.sql
--
--    DESCRIPTION
--
--    NOTES
--      Assumes the SYS user is connected.
--
--    Arguments:
--      1 - usrn   = sumnevaASR Schema Name
--
--    MODIFIED   (MM/DD/YYYY)
--      dgault    1/7/09 7:19 PM - Created    
--      lschilde  3/22/21 7:19 PM - Updated 

set termout on
set define '^'
set concat on
set concat .
set verify off
--

GRANT CREATE VIEW TO ^esert_user;

GRANT CREATE PROCEDURE TO ^esert_user;

GRANT CREATE PUBLIC SYNONYM TO ^esert_user;

-- For PL/PDF

GRANT SELECT on sys.v_$database to ^esert_user;

GRANT EXECUTE on sys.dbms_crypto to ^esert_user;

GRANT EXECUTE on sys.dbms_lob to  ^esert_user;

DECLARE
 l_sql VARCHAR2(255);
BEGIN

FOR x IN (SELECT MAX(username) username FROM all_users WHERE username = '^sert_apex_version')
LOOP

  l_sql := 'GRANT SELECT ON ' || x.username || '.wwv_flow_sessions$ TO ^esert_user';

END LOOP;

EXECUTE IMMEDIATE l_sql;

END;
/

set feedback off;
set termout off;