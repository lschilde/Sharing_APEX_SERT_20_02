PROMPT == SV_SEC_VERSION_DML
set define on
set define '^'
INSERT INTO sv_sec_version VALUES ('^apex_version');

COMMIT
/